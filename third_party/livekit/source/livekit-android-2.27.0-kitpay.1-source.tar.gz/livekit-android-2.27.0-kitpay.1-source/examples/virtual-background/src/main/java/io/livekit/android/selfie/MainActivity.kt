/*
 * Copyright 2024-2025 LiveKit, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.selfie

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import io.livekit.android.renderer.TextureViewRenderer

class MainActivity : AppCompatActivity() {

    lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewModel = ViewModelProvider(this)[MainViewModel::class.java]

        val enableButton = findViewById<Button>(R.id.button)
        enableButton.setOnClickListener {
            val state = viewModel.toggleProcessor()

            enableButton.setText(if (state) "Disable" else "Enable")
        }

        val enableBackgroundButton = findViewById<Button>(R.id.buttonBackground)
        enableBackgroundButton.setOnClickListener {
            val state = viewModel.toggleVirtualBackground()
            enableBackgroundButton.setText(if (state) "Disable Background" else "Enable Background")
        }

        val flipCameraButton = findViewById<Button>(R.id.buttonFlip)
        flipCameraButton.setOnClickListener {
            viewModel.flipCamera()
        }

        val renderer = findViewById<TextureViewRenderer>(R.id.renderer)
        viewModel.room.initVideoRenderer(renderer)
        viewModel.track.observe(this) { track ->
            track?.addRenderer(renderer)
        }

        findViewById<Button>(R.id.buttonIncreaseBlur).setOnClickListener {
            viewModel.increaseBlur()
        }
        findViewById<Button>(R.id.buttonDecreaseBlur).setOnClickListener {
            viewModel.decreaseBlur()
        }

        requestNeededPermissions {
            viewModel.startCapture()
        }
    }
}

fun ComponentActivity.requestNeededPermissions(onPermissionsGranted: (() -> Unit)? = null) {
    val requestPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions(),
        ) { grants ->
            // Check if any permissions weren't granted.
            for (grant in grants.entries) {
                if (!grant.value) {
                    Toast.makeText(
                        this,
                        "Missing permission: ${grant.key}",
                        Toast.LENGTH_SHORT,
                    )
                        .show()
                }
            }

            // If all granted, notify if needed.
            if (onPermissionsGranted != null && grants.all { it.value }) {
                onPermissionsGranted()
            }
        }

    val neededPermissions = listOf(Manifest.permission.CAMERA)
        .filter { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_DENIED }
        .toTypedArray()

    if (neededPermissions.isNotEmpty()) {
        requestPermissionLauncher.launch(neededPermissions)
    } else {
        onPermissionsGranted?.invoke()
    }
}
