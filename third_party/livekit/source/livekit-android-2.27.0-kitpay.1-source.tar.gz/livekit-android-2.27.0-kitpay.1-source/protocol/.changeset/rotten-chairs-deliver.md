---

---

Wire CanManageAgentSession through VideoGrant
