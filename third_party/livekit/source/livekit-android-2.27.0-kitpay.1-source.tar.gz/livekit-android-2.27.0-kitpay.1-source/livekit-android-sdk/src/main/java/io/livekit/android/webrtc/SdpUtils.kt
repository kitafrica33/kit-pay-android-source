/*
 * Copyright 2023-2026 LiveKit, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Parts of this source code come from https://github.com/ggarber/sdpparser
 *
 * MIT License
 *
 * Copyright (c) 2023 Gustavo Garcia
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package io.livekit.android.webrtc

import io.livekit.android.util.LKLog

/**
 * A deliberately small, lossless SDP document model.
 *
 * WebRTC creates the SDP, so this class does not try to validate or normalise
 * the complete grammar. It keeps every input line and line ending verbatim and
 * exposes only the media attributes that LiveKit needs to munge.
 *
 * @suppress
 */
internal class SdpSessionDescription private constructor(
    private val lines: MutableList<SdpLine>,
) {
    val mediaDescriptions: List<SdpMediaDescription>
        get() = lines
            .filter { it.text.startsWith(MEDIA_PREFIX) }
            .map { SdpMediaDescription(this, it) }

    override fun toString(): String = buildString {
        lines.forEach { line ->
            append(line.text)
            append(line.ending)
        }
    }

    internal fun linesFor(mediaLine: SdpLine): List<SdpLine> {
        val start = lines.indexOfIdentity(mediaLine)
        if (start < 0) {
            return emptyList()
        }
        val end = lines.indexOfFirstAfter(start) { it.text.startsWith(MEDIA_PREFIX) }
            .takeUnless { it < 0 }
            ?: lines.size
        return lines.subList(start + 1, end)
    }

    internal fun addAttribute(mediaLine: SdpLine, attribute: SdpAttribute) {
        val start = lines.indexOfIdentity(mediaLine)
        require(start >= 0) { "media section is not part of this SDP document" }

        val end = lines.indexOfFirstAfter(start) { it.text.startsWith(MEDIA_PREFIX) }
            .takeUnless { it < 0 }
            ?: lines.size
        val ending = preferredEnding(start, end)
        val newLine = attribute.line

        if (end == lines.size) {
            val previous = lines.lastOrNull()
            if (previous == null) {
                newLine.ending = ""
            } else if (previous.ending.isEmpty()) {
                // Preserve whether the source had a trailing newline after appending.
                previous.ending = ending
                newLine.ending = ""
            } else {
                newLine.ending = ending
            }
        } else {
            newLine.ending = ending
        }
        lines.add(end, newLine)
    }

    private fun preferredEnding(start: Int, end: Int): String {
        for (index in start until end) {
            if (lines[index].ending.isNotEmpty()) {
                return lines[index].ending
            }
        }
        return lines.firstOrNull { it.ending.isNotEmpty() }?.ending ?: CRLF
    }

    companion object {
        private const val MEDIA_PREFIX = "m="
        private const val CRLF = "\r\n"

        fun parse(description: String): SdpSessionDescription {
            val lines = mutableListOf<SdpLine>()
            var lineStart = 0
            var index = 0
            while (index < description.length) {
                val ending = when (description[index]) {
                    '\r' -> if (index + 1 < description.length && description[index + 1] == '\n') CRLF else "\r"
                    '\n' -> "\n"
                    else -> {
                        index++
                        continue
                    }
                }
                lines += SdpLine(description.substring(lineStart, index), ending)
                index += ending.length
                lineStart = index
            }
            if (lineStart < description.length) {
                lines += SdpLine(description.substring(lineStart), "")
            }
            return SdpSessionDescription(lines)
        }
    }
}

/** @suppress */
internal class SdpMediaDescription internal constructor(
    private val document: SdpSessionDescription,
    private val mediaLine: SdpLine,
) {
    val mediaType: String?
        get() {
            if (!mediaLine.text.startsWith("m=")) {
                return null
            }
            return mediaLine.text
                .substring(2)
                .trimStart()
                .takeWhile { !it.isWhitespace() }
                .ifEmpty { null }
        }

    internal fun getAttributes(name: String): List<SdpAttribute> = document
        .linesFor(mediaLine)
        .mapNotNull(SdpAttribute::from)
        .filter { it.name == name }

    internal fun addAttribute(attribute: SdpAttribute) {
        document.addAttribute(mediaLine, attribute)
    }
}

/** @suppress */
internal class SdpAttribute private constructor(
    internal val line: SdpLine,
) {
    val name: String
        get() = parseAttribute(line.text)?.first.orEmpty()

    var value: String
        get() = parseAttribute(line.text)?.second.orEmpty()
        set(value) {
            val currentName = name
            require(currentName.isNotEmpty()) { "cannot mutate a malformed SDP attribute" }
            line.text = "a=$currentName:$value"
        }

    internal fun encode(): String = line.text

    companion object {
        fun create(name: String, value: String? = null): SdpAttribute {
            require(name.isNotEmpty() && ':' !in name) { "invalid SDP attribute name" }
            val text = if (value == null) "a=$name" else "a=$name:$value"
            return SdpAttribute(SdpLine(text, ""))
        }

        fun from(line: SdpLine): SdpAttribute? = if (parseAttribute(line.text) == null) null else SdpAttribute(line)

        private fun parseAttribute(text: String): Pair<String, String?>? {
            if (!text.startsWith("a=")) {
                return null
            }
            val body = text.substring(2)
            val separator = body.indexOf(':')
            val name = if (separator < 0) body else body.substring(0, separator)
            if (name.isEmpty() || name.any(Char::isWhitespace)) {
                return null
            }
            return name to if (separator < 0) null else body.substring(separator + 1)
        }
    }
}

internal class SdpLine(
    var text: String,
    var ending: String,
)

/** @suppress */
data class SdpRtp(val payload: Long, val codec: String, val rate: Long?, val encoding: String?)

/** @suppress */
internal fun SdpMediaDescription.getRtps(): List<Pair<SdpAttribute, SdpRtp>> = getAttributes("rtpmap")
    .mapNotNull { attribute ->
        val rtp = tryParseRtp(attribute.value)
        if (rtp == null) {
            LKLog.w { "could not parse rtpmap: ${attribute.encode()}" }
            null
        } else {
            attribute to rtp
        }
    }

private val RTP = """^(\d+)\s+([^\s/]+)(?:\s*/\s*(\d+)(?:\s*/\s*(\S+))?)?\s*$""".toRegex()

internal fun tryParseRtp(string: String): SdpRtp? {
    val match = RTP.matchEntire(string) ?: return null
    val (payload, codec, rate, encoding) = match.destructured
    return SdpRtp(
        payload = payload.toLongOrNull() ?: return null,
        codec = codec,
        rate = rate.toLongOrNull(),
        encoding = encoding.ifEmpty { null },
    )
}

/** @suppress */
data class SdpMsid(
    /** holds the msid-id (and msid-appdata if available) */
    val value: String,
)

/** @suppress */
internal fun SdpMediaDescription.getMsid(): SdpMsid? = getAttributes("msid")
    .firstOrNull()
    ?.let { SdpMsid(it.value) }

/** @suppress */
data class SdpFmtp(val payload: Long, val config: String) {
    internal fun toAttribute(): SdpAttribute = SdpAttribute.create("fmtp", "$payload $config")
}

/** @suppress */
internal fun SdpMediaDescription.getFmtps(): List<Pair<SdpAttribute, SdpFmtp>> = getAttributes("fmtp")
    .mapNotNull { attribute ->
        val fmtp = tryParseFmtp(attribute.value)
        if (fmtp == null) {
            LKLog.w { "could not parse fmtp: ${attribute.encode()}" }
            null
        } else {
            attribute to fmtp
        }
    }

private val FMTP = """^(\d+)(?:[ \t]+(.*))?$""".toRegex()

internal fun tryParseFmtp(string: String): SdpFmtp? {
    val match = FMTP.matchEntire(string) ?: return null
    val (payload, config) = match.destructured
    return SdpFmtp(payload.toLongOrNull() ?: return null, config)
}

/** @suppress */
data class SdpExt(
    val value: Long,
    val direction: String?,
    val encryptUri: String?,
    val uri: String,
    val config: String?,
) {
    internal fun toAttribute(): SdpAttribute = SdpAttribute.create(
        "extmap",
        buildString {
            append(value)
            if (direction != null) {
                append('/')
                append(direction)
            }
            append(' ')
            if (encryptUri != null) {
                append(encryptUri)
                append(' ')
            }
            append(uri)
            if (config != null) {
                append(' ')
                append(config)
            }
        },
    )
}

/** @suppress */
internal fun SdpMediaDescription.getExts(): List<Pair<SdpAttribute, SdpExt>> = getAttributes("extmap")
    .mapNotNull { attribute ->
        val ext = tryParseExt(attribute.value)
        if (ext == null) {
            LKLog.w { "could not parse extmap: ${attribute.encode()}" }
            null
        } else {
            attribute to ext
        }
    }

private val EXT =
    """^(\d+)(?:/(sendonly|recvonly|sendrecv|inactive))?[ \t]+(?:(urn:ietf:params:rtp-hdrext:encrypt)[ \t]+)?(\S+)(?:[ \t]+(.*))?$"""
        .toRegex()

internal fun tryParseExt(string: String): SdpExt? {
    val match = EXT.matchEntire(string) ?: return null
    val (value, direction, encryptUri, uri, config) = match.destructured
    return SdpExt(
        value = value.toLongOrNull() ?: return null,
        direction = direction.ifEmpty { null },
        encryptUri = encryptUri.ifEmpty { null },
        uri = uri,
        config = config.ifEmpty { null },
    )
}

private fun MutableList<SdpLine>.indexOfIdentity(target: SdpLine): Int = indexOfFirst { it === target }

private inline fun MutableList<SdpLine>.indexOfFirstAfter(start: Int, predicate: (SdpLine) -> Boolean): Int {
    for (index in start + 1 until size) {
        if (predicate(this[index])) {
            return index
        }
    }
    return -1
}
