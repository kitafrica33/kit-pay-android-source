# Kotlin Serialization Proguard Rules
########################################

-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt # core serialization annotations

# kotlinx-serialization-json specific. Add this if you have java.lang.NoClassDefFoundError kotlinx.serialization.json.JsonObjectSerializer
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}

-keep,includedescriptorclasses class io.livekit.android.**$$serializer { *; }

-keepclasseswithmembers class io.livekit.android.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# WebRTC
#########################################
# Ensure JNI native method names and descriptors are preserved (Java -> native).
-keepclasseswithmembernames,includedescriptorclasses class livekit.org.webrtc.** {
    native <methods>;
}

# Ensure java methods called from Native are preserved (native -> Java).
-keepclasseswithmembers,includedescriptorclasses class * {
    @livekit.**.CalledByNative <methods>;
}
-keepclasseswithmembers,includedescriptorclasses class * {
    @livekit.**.CalledByNativeUnchecked <methods>;
}

# Protobuf
#########################################
-keepclassmembers class livekit.** extends com.google.protobuf.GeneratedMessageLite {
  <fields>;
}
-keepclassmembers class com.google.protobuf.** extends com.google.protobuf.GeneratedMessageLite {
  <fields>;
}
