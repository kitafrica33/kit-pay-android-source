/*
 * Copyright 2024-2026 LiveKit, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.livekit.android.test.mock

import io.livekit.android.room.provisions.LKObjects
import livekit.org.webrtc.audio.AudioDeviceModule

object MockLKObjects {
    fun get(): LKObjects {
        return LKObjects(
            eglBaseProvider = { MockEglBase() },
            audioDeviceModuleProvider = {
                object : AudioDeviceModule {
                    override fun getNative(webrtcEnvRef: Long): Long {
                        return 1
                    }

                    override fun release() {}

                    override fun setSpeakerMute(p0: Boolean) {}

                    override fun setMicrophoneMute(p0: Boolean) {}
                }
            },
        )
    }
}
